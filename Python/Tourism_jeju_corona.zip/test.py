import Main
import Naver



print(Main.sajun())